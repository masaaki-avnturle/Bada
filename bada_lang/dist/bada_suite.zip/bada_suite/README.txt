Bada Application Suite
======================

Open index.html in a browser to launch any application.

bin/bada       run any app from one executable (needs Python 3):
                 ./bin/bada list
                 ./bin/bada run quantum_os
                 ./bin/bada mayu
bin/mayu       the mayu registry remapper, standalone.
src/           full Bada source (VM, libraries, apps, tests).

Built with the Bada language - a custom compiler + VM.
